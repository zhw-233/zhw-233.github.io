# C Gomoku for Windows

这是一个使用 C 语言和 Windows 原生 Win32 API/GDI 编写的简单五子棋程序，不依赖第三方图形库。

## 功能

- 打开一个图形化窗口
- 鼠标点击棋盘交叉点落子
- 黑白双方由用户轮流点击落子
- 自动判断横、竖、斜方向五子连珠
- 显示当前回合、胜负或平局
- 支持重新开始

## 文件结构

```text
src/main.c          主程序源码
build_mingw.bat    MinGW 编译脚本
README.md          编译和操作说明
```

## Windows 编译方式

### 方式一：MinGW-w64

先安装 MinGW-w64，并确保 `gcc` 已加入系统 `PATH`。

推荐使用 MSYS2 的 UCRT64 环境，并安装到没有空格的路径，例如：

```text
C:\msys64
```

不要把 MinGW-w64 安装在类似下面这种带空格的目录：

```text
C:\Program Files\mingw64
```

否则链接阶段可能出现 `cannot find C:/Program` 或找不到 `default-manifest.o` 的错误。

在项目根目录打开命令提示符或 PowerShell，执行：

```bat
build_mingw.bat
```

编译成功后会生成：

```text
build/gomoku.exe
```

也可以手动执行：

```bat
gcc src\main.c -o build\gomoku.exe -municode -mwindows -lgdi32 -luser32
```

### 方式二：Visual Studio Developer Command Prompt

在项目根目录执行：

```bat
mkdir build
cl /DUNICODE /D_UNICODE /W4 /Fe:build\gomoku.exe src\main.c user32.lib gdi32.lib /link /SUBSYSTEM:WINDOWS
```

## 操作说明

- 打开 `gomoku.exe` 后会显示 15x15 棋盘。
- 黑棋先手。
- 用鼠标点击棋盘交叉点落子。
- 黑白双方自动交替。
- 已有棋子的点不能重复落子。
- 任意一方横向、纵向或斜向连成 5 子即获胜。
- 点击窗口右下角 `Reset` 按钮可重新开始。
- 也可以按 `R` 或 `F2` 重新开始。

## 说明

程序使用 Windows 自带的 `user32` 和 `gdi32`，所以不需要安装 SDL、raylib、Qt 等额外图形库。
