@echo off
setlocal

if not exist build mkdir build

gcc src\main.c -o build\gomoku.exe -municode -mwindows -lgdi32 -luser32

if errorlevel 1 (
    echo Build failed.
    exit /b 1
)

echo Build finished: build\gomoku.exe
