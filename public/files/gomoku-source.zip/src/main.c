#define UNICODE
#define _UNICODE

#include <windows.h>
#include <windowsx.h>
#include <stdbool.h>

#define BOARD_SIZE 15
#define CELL_SIZE 36
#define BOARD_MARGIN 54
#define STATUS_TOP 590
#define CLIENT_WIDTH 620
#define CLIENT_HEIGHT 680

typedef enum {
    EMPTY = 0,
    BLACK = 1,
    WHITE = 2
} Stone;

static Stone board[BOARD_SIZE][BOARD_SIZE];
static Stone current_player = BLACK;
static Stone winner = EMPTY;
static bool game_over = false;
static int move_count = 0;

static const RECT reset_button = { 450, 615, 570, 652 };

static int board_origin_x(void) {
    return BOARD_MARGIN;
}

static int board_origin_y(void) {
    return BOARD_MARGIN;
}

static int board_pixel_size(void) {
    return CELL_SIZE * (BOARD_SIZE - 1);
}

static void reset_game(HWND hwnd) {
    for (int row = 0; row < BOARD_SIZE; row++) {
        for (int col = 0; col < BOARD_SIZE; col++) {
            board[row][col] = EMPTY;
        }
    }

    current_player = BLACK;
    winner = EMPTY;
    game_over = false;
    move_count = 0;
    InvalidateRect(hwnd, NULL, TRUE);
}

static bool point_in_rect(int x, int y, const RECT *rect) {
    return x >= rect->left && x <= rect->right && y >= rect->top && y <= rect->bottom;
}

static bool get_board_position(int x, int y, int *out_row, int *out_col) {
    const int origin_x = board_origin_x();
    const int origin_y = board_origin_y();
    const int board_end_x = origin_x + board_pixel_size();
    const int board_end_y = origin_y + board_pixel_size();
    const int snap_radius = CELL_SIZE / 2;

    if (x < origin_x - snap_radius || x > board_end_x + snap_radius ||
        y < origin_y - snap_radius || y > board_end_y + snap_radius) {
        return false;
    }

    int col = (x - origin_x + CELL_SIZE / 2) / CELL_SIZE;
    int row = (y - origin_y + CELL_SIZE / 2) / CELL_SIZE;

    if (row < 0 || row >= BOARD_SIZE || col < 0 || col >= BOARD_SIZE) {
        return false;
    }

    *out_row = row;
    *out_col = col;
    return true;
}

static int count_in_direction(int row, int col, int delta_row, int delta_col, Stone stone) {
    int count = 0;
    row += delta_row;
    col += delta_col;

    while (row >= 0 && row < BOARD_SIZE && col >= 0 && col < BOARD_SIZE &&
           board[row][col] == stone) {
        count++;
        row += delta_row;
        col += delta_col;
    }

    return count;
}

static bool has_five_from(int row, int col) {
    const Stone stone = board[row][col];
    const int directions[4][2] = {
        { 0, 1 },
        { 1, 0 },
        { 1, 1 },
        { 1, -1 }
    };

    for (int i = 0; i < 4; i++) {
        int dr = directions[i][0];
        int dc = directions[i][1];
        int total = 1;
        total += count_in_direction(row, col, dr, dc, stone);
        total += count_in_direction(row, col, -dr, -dc, stone);

        if (total >= 5) {
            return true;
        }
    }

    return false;
}

static void place_stone(HWND hwnd, int row, int col) {
    if (game_over || board[row][col] != EMPTY) {
        return;
    }

    board[row][col] = current_player;
    move_count++;

    if (has_five_from(row, col)) {
        winner = current_player;
        game_over = true;
    } else if (move_count == BOARD_SIZE * BOARD_SIZE) {
        game_over = true;
    } else {
        current_player = (current_player == BLACK) ? WHITE : BLACK;
    }

    InvalidateRect(hwnd, NULL, TRUE);
}

static void draw_board(HDC hdc) {
    const int origin_x = board_origin_x();
    const int origin_y = board_origin_y();
    const int size = board_pixel_size();

    HBRUSH board_brush = CreateSolidBrush(RGB(230, 184, 108));
    RECT board_rect = {
        origin_x - 30,
        origin_y - 30,
        origin_x + size + 30,
        origin_y + size + 30
    };
    FillRect(hdc, &board_rect, board_brush);
    DeleteObject(board_brush);

    HPEN grid_pen = CreatePen(PS_SOLID, 1, RGB(70, 45, 20));
    HPEN old_pen = (HPEN)SelectObject(hdc, grid_pen);

    for (int i = 0; i < BOARD_SIZE; i++) {
        int pos = i * CELL_SIZE;
        MoveToEx(hdc, origin_x, origin_y + pos, NULL);
        LineTo(hdc, origin_x + size, origin_y + pos);
        MoveToEx(hdc, origin_x + pos, origin_y, NULL);
        LineTo(hdc, origin_x + pos, origin_y + size);
    }

    SelectObject(hdc, old_pen);
    DeleteObject(grid_pen);

    HBRUSH star_brush = CreateSolidBrush(RGB(70, 45, 20));
    HBRUSH old_brush = (HBRUSH)SelectObject(hdc, star_brush);
    const int stars[5][2] = {
        { 3, 3 }, { 3, 11 }, { 7, 7 }, { 11, 3 }, { 11, 11 }
    };

    for (int i = 0; i < 5; i++) {
        int x = origin_x + stars[i][1] * CELL_SIZE;
        int y = origin_y + stars[i][0] * CELL_SIZE;
        Ellipse(hdc, x - 4, y - 4, x + 4, y + 4);
    }

    SelectObject(hdc, old_brush);
    DeleteObject(star_brush);
}

static void draw_stones(HDC hdc) {
    const int origin_x = board_origin_x();
    const int origin_y = board_origin_y();
    const int radius = 15;

    HPEN outline_pen = CreatePen(PS_SOLID, 1, RGB(40, 30, 24));
    HPEN old_pen = (HPEN)SelectObject(hdc, outline_pen);

    for (int row = 0; row < BOARD_SIZE; row++) {
        for (int col = 0; col < BOARD_SIZE; col++) {
            if (board[row][col] == EMPTY) {
                continue;
            }

            int x = origin_x + col * CELL_SIZE;
            int y = origin_y + row * CELL_SIZE;
            COLORREF color = board[row][col] == BLACK ? RGB(24, 24, 24) : RGB(245, 240, 230);
            HBRUSH stone_brush = CreateSolidBrush(color);
            HBRUSH old_brush = (HBRUSH)SelectObject(hdc, stone_brush);

            Ellipse(hdc, x - radius, y - radius, x + radius, y + radius);

            SelectObject(hdc, old_brush);
            DeleteObject(stone_brush);
        }
    }

    SelectObject(hdc, old_pen);
    DeleteObject(outline_pen);
}

static void draw_status(HDC hdc) {
    SetBkMode(hdc, TRANSPARENT);
    SetTextColor(hdc, RGB(32, 32, 32));

    HFONT font = CreateFontW(
        24, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Microsoft YaHei");
    HFONT old_font = (HFONT)SelectObject(hdc, font);

    wchar_t message[128];
    if (winner == BLACK) {
        lstrcpyW(message, L"Black wins!");
    } else if (winner == WHITE) {
        lstrcpyW(message, L"White wins!");
    } else if (game_over) {
        lstrcpyW(message, L"Draw game.");
    } else if (current_player == BLACK) {
        lstrcpyW(message, L"Turn: Black");
    } else {
        lstrcpyW(message, L"Turn: White");
    }

    RECT status_rect = { 50, STATUS_TOP, 380, STATUS_TOP + 60 };
    DrawTextW(hdc, message, -1, &status_rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

    HBRUSH button_brush = CreateSolidBrush(RGB(242, 242, 242));
    FillRect(hdc, &reset_button, button_brush);
    DeleteObject(button_brush);

    HPEN button_pen = CreatePen(PS_SOLID, 1, RGB(80, 80, 80));
    HPEN old_pen = (HPEN)SelectObject(hdc, button_pen);
    HBRUSH old_brush = (HBRUSH)SelectObject(hdc, GetStockObject(NULL_BRUSH));
    Rectangle(hdc, reset_button.left, reset_button.top, reset_button.right, reset_button.bottom);
    SelectObject(hdc, old_brush);
    SelectObject(hdc, old_pen);
    DeleteObject(button_pen);

    DrawTextW(hdc, L"Reset", -1, (RECT *)&reset_button, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

    SelectObject(hdc, old_font);
    DeleteObject(font);
}

static void draw_scene(HWND hwnd, HDC hdc) {
    RECT client_rect;
    GetClientRect(hwnd, &client_rect);

    HBRUSH background = CreateSolidBrush(RGB(250, 246, 238));
    FillRect(hdc, &client_rect, background);
    DeleteObject(background);

    draw_board(hdc);
    draw_stones(hdc);
    draw_status(hdc);
}

static LRESULT CALLBACK window_proc(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam) {
    switch (message) {
    case WM_LBUTTONDOWN: {
        int x = GET_X_LPARAM(lparam);
        int y = GET_Y_LPARAM(lparam);

        if (point_in_rect(x, y, &reset_button)) {
            reset_game(hwnd);
            return 0;
        }

        int row = 0;
        int col = 0;
        if (get_board_position(x, y, &row, &col)) {
            place_stone(hwnd, row, col);
        }
        return 0;
    }

    case WM_KEYDOWN:
        if (wparam == 'R' || wparam == VK_F2) {
            reset_game(hwnd);
            return 0;
        }
        break;

    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);
        draw_scene(hwnd, hdc);
        EndPaint(hwnd, &ps);
        return 0;
    }

    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProcW(hwnd, message, wparam, lparam);
}

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE previous_instance, PWSTR command_line, int show_command) {
    (void)previous_instance;
    (void)command_line;

    const wchar_t class_name[] = L"GomokuWindowClass";

    WNDCLASSW window_class = { 0 };
    window_class.lpfnWndProc = window_proc;
    window_class.hInstance = instance;
    window_class.lpszClassName = class_name;
    window_class.hCursor = LoadCursor(NULL, IDC_ARROW);
    window_class.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);

    if (!RegisterClassW(&window_class)) {
        MessageBoxW(NULL, L"Failed to register window class.", L"Gomoku", MB_ICONERROR);
        return 1;
    }

    RECT window_rect = { 0, 0, CLIENT_WIDTH, CLIENT_HEIGHT };
    AdjustWindowRect(&window_rect, WS_OVERLAPPEDWINDOW, FALSE);

    HWND hwnd = CreateWindowExW(
        0,
        class_name,
        L"Gomoku",
        WS_OVERLAPPEDWINDOW & ~WS_MAXIMIZEBOX & ~WS_THICKFRAME,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        window_rect.right - window_rect.left,
        window_rect.bottom - window_rect.top,
        NULL,
        NULL,
        instance,
        NULL);

    if (!hwnd) {
        MessageBoxW(NULL, L"Failed to create window.", L"Gomoku", MB_ICONERROR);
        return 1;
    }

    reset_game(hwnd);
    ShowWindow(hwnd, show_command);
    UpdateWindow(hwnd);

    MSG msg;
    while (GetMessageW(&msg, NULL, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    return (int)msg.wParam;
}
